package com.gongdan.Command;

public interface AbstractCommand
{
    void execute();
}
