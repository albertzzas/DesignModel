package com.gongdan.Command;

public class Client
{
    public static void main(String[] args)
    {
        /*Chef chef = new Chef();
        Command command = new CookCommand(chef);
        Consumer consumer = new Consumer();
        consumer.addCommand(command);
        consumer.orderDishes();*/

        Athlete athlete = new Athlete();
        AttackCommand attackCommand = new AttackCommand();
        attackCommand.setAthlete(athlete);
        DefenseCommand defenseCommand = new DefenseCommand();
        defenseCommand.setAthlete(athlete);
        Coach coach = new Coach(attackCommand, defenseCommand);
        coach.attack();
        coach.defense();
        coach.attack();
        coach.defense();
        coach.defense();
        System.out.println("回放教练发出的命令");
        coach.rebroadcast();
    }
}
