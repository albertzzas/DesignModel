package com.gongdan.Command;

public class Invoker
{
    private AbstractCommand command;
}
