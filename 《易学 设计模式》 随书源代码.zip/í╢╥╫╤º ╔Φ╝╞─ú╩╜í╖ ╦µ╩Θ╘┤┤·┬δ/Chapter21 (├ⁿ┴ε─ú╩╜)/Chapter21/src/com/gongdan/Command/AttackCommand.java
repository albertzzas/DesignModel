package com.gongdan.Command;

public class AttackCommand extends CommandNew
{
    public void execute()
    {
        super.getAthlete().attack();
    }
}
