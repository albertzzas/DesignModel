package com.gongdan.Command;

public class Receiver
{
    public void action()
    {

    }
}
