package com.gongdan.Command;

public class Athlete
{
    public void attack()
    {
        System.out.println("球员开始进攻");
    }

    public void defense()
    {
        System.out.println("球员开始防守");
    }
}
