package com.gongdan.Command;

public class ConcreteCommand implements AbstractCommand
{
    public void execute()
    {
        receiver.action();
    }

    private Receiver receiver;
}
