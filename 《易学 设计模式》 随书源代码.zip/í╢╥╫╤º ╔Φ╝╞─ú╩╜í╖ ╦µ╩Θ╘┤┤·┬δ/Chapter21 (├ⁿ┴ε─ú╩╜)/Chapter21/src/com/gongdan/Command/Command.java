package com.gongdan.Command;

public interface Command
{
    void execute();
}
