package com.gongdan.Command;

public class DefenseCommand extends CommandNew
{
    public void execute()
    {
        super.getAthlete().defense();
    }
}
