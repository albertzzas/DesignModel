package com.gongdan.Command;

public class Chef
{
    public void cook()
    {
        System.out.println("厨师开始做菜");
    }
}
