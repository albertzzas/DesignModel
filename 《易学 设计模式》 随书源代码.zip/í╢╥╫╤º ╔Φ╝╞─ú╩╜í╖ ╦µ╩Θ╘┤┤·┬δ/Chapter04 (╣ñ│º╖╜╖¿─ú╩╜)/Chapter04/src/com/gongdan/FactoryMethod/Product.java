package com.gongdan.FactoryMethod;

public interface Product
{

}
