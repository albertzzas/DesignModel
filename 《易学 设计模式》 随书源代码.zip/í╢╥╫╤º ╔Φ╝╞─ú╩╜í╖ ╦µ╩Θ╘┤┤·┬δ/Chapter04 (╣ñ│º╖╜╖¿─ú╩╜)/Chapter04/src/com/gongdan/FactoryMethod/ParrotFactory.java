package com.gongdan.FactoryMethod;

import com.gongdan.Animal;
import com.gongdan.Parrot;

public class ParrotFactory implements Factory
{
    public Animal CreateAnimal()
    {
        return new Parrot();
    }
}
