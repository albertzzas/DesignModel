package com.gongdan.FactoryMethod;

import com.gongdan.Animal;

public class Client
{
    public static void main(String args[])
    {
        Factory factory = new TigerFactory();
        Animal animal = factory.CreateAnimal();
        animal.Eat();
        factory = new DolphinFactory();
        animal = factory.CreateAnimal();
        animal.Eat();
        factory = new ParrotFactory();
        animal = factory.CreateAnimal();
        animal.Eat();
    }
}
