package com.gongdan.FactoryMethod;

import com.gongdan.Animal;
import com.gongdan.Tiger;

public class TigerFactory implements Factory
{
    public Animal CreateAnimal()
    {
        return new Tiger();
    }
}
