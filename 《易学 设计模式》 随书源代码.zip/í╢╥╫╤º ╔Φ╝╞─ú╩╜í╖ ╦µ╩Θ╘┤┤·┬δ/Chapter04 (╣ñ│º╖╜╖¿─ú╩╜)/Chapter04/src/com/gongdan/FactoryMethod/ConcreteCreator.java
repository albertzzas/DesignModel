package com.gongdan.FactoryMethod;

public class ConcreteCreator implements Creator
{
    public Product FactoryMethod()
    {
        return new ConcreteProduct();
    }
}
