package com.gongdan.FactoryMethod;

import com.gongdan.Animal;
import com.gongdan.Dolphin;

public class DolphinFactory implements Factory
{
    public Animal CreateAnimal()
    {
        return new Dolphin();
    }
}
