package com.gongdan.FactoryMethod;

public class ConcreteProduct implements Product
{
    public ConcreteProduct()
    {
    }
}
