package com.gongdan.FactoryMethod;

public interface Creator
{
    Product FactoryMethod();
}
