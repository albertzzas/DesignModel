package com.gongdan.FactoryMethod;

import com.gongdan.Animal;

public interface Factory
{
    public Animal CreateAnimal();
}
