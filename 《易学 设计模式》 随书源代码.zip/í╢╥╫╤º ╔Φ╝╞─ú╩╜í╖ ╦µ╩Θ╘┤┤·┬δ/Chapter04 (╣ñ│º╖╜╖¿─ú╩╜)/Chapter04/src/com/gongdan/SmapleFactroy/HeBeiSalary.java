package com.gongdan.SmapleFactroy;

public class HeBeiSalary implements  Salary
{
    public void ComputeSalary()
    {
        System.out.println("开始计算河北子公司的薪资");
    }
}
