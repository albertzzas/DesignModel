package com.gongdan.SmapleFactroy;

public interface Salary
{
    void ComputeSalary();
}
