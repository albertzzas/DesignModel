package com.gongdan.SmapleFactroy;

public class SampleFactory
{
    public static Salary CreateSalary(String name)
    {
        if ("HeBei".equals(name))
        {
            return new HeBeiSalary();
        }
        else if ("JiLin".equals(name))
        {
            return new JiLinSalary();
        }
        return null;
    }
}
