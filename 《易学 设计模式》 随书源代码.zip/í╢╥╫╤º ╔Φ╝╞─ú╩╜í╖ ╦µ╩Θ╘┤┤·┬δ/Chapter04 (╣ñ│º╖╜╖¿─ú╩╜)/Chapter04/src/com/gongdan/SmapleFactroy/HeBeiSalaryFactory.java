package com.gongdan.SmapleFactroy;

public class HeBeiSalaryFactory implements Factory
{
    public Salary CreateSalary()
    {
        return new HeBeiSalary();
    }
}
