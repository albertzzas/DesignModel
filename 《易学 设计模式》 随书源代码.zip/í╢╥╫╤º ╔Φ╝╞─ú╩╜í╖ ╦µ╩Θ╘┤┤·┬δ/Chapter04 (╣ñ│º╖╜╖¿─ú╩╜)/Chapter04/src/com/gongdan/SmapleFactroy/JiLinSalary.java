package com.gongdan.SmapleFactroy;

public class JiLinSalary implements Salary
{
    public void ComputeSalary()
    {
        System.out.println("开始计算吉林子公司的薪资");
    }
}
