package com.gongdan.SmapleFactroy;

public interface Factory
{
    public Salary CreateSalary();
}
