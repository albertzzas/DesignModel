package com.gongdan.SmapleFactroy;

public class JiLinSalaryFactory implements Factory
{
    public Salary CreateSalary()
    {
        return new JiLinSalary();
    }
}
