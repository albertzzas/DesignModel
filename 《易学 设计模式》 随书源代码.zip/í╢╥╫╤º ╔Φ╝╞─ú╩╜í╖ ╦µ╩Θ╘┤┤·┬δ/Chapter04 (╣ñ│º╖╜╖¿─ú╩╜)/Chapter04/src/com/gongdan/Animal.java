package com.gongdan;

public interface Animal
{
    void Eat();
}
