package com.gongdan.Flyweight;

public interface Flyweight1
{
    public void Operation();
}
