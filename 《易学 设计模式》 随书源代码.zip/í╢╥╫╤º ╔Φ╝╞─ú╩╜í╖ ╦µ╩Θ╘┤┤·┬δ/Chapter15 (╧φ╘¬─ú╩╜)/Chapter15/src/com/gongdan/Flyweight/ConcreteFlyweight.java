package com.gongdan.Flyweight;

public class ConcreteFlyweight implements Flyweight1
{
    public ConcreteFlyweight()
    {

    }

    public void Operation()
    {

    }
}
