package com.gongdan.Flyweight;

public interface Flyweight
{
    public String getName();
}
