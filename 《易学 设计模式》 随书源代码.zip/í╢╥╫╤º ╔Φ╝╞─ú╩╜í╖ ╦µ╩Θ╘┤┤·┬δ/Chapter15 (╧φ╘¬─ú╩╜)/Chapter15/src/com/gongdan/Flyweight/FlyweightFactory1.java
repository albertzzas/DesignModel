package com.gongdan.Flyweight;

public class FlyweightFactory1
{
    private Flyweight1 flyweight1;

    public Flyweight1 factory()
    {
        return null;
    }
}
