package com.gongdan.Visitor;

public interface Goods
{
    double accept(Visitor visitor);
}
