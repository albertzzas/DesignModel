package com.gongdan.Visitor;

public interface Element
{
    void accept(VisitorPrinciple visitor);
}
