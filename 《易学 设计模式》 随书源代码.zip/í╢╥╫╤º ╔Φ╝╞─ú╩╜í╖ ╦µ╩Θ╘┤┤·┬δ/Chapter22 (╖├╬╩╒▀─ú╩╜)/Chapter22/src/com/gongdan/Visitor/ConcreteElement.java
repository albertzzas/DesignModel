package com.gongdan.Visitor;

public class ConcreteElement implements Element
{
    public void accept(VisitorPrinciple visitor)
    {
        visitor.visitConcreteElement(this);
    }
}
