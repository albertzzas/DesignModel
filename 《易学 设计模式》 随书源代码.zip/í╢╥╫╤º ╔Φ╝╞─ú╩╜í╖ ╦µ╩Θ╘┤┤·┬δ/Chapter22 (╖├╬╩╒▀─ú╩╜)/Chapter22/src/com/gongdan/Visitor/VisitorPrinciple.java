package com.gongdan.Visitor;

public interface VisitorPrinciple
{
    void visitConcreteElement(ConcreteElement element);
}
