package com.gongdan.Visitor;

public interface Visitor
{
    double visit(WineNew wine);

    double visit(PigNew pig);

    double visit(TelevisionNew television);
}