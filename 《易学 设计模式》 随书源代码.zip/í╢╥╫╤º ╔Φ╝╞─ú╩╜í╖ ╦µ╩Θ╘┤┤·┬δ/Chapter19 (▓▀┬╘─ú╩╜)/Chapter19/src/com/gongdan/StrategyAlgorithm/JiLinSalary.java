package com.gongdan.StrategyAlgorithm;

public class JiLinSalary implements Salary
{
    public void computeSalary()
    {
        System.out.println("采用吉林算法计算基本工资");
    }
}
