package com.gongdan.StrategyAlgorithm;

public class JiLinInsurance implements Insurance
{
    public void computeInsurance()
    {
        System.out.println("采用吉林算法计算保险");
    }
}
