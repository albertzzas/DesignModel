package com.gongdan.StrategyAlgorithm;

public interface Salary
{
    public void computeSalary();
}
