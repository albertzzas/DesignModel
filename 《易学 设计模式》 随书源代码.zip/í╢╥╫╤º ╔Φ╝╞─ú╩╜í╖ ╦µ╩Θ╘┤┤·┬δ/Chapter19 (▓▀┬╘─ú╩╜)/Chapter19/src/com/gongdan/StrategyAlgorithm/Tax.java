package com.gongdan.StrategyAlgorithm;

public interface Tax
{
    public void computeTax();
}
