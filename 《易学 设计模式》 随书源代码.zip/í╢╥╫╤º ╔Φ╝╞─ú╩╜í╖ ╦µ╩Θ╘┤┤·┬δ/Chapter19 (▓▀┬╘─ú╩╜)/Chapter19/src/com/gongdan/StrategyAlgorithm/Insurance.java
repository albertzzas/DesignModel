package com.gongdan.StrategyAlgorithm;

public interface Insurance
{
    public void computeInsurance();
}
