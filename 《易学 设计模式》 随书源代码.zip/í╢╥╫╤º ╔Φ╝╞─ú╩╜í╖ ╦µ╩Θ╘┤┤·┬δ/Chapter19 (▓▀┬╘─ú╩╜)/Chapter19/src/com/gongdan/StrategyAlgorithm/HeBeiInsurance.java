package com.gongdan.StrategyAlgorithm;

public class HeBeiInsurance implements Insurance
{
    public void computeInsurance()
    {
        System.out.println("采用河北算法计算保险");
    }
}
