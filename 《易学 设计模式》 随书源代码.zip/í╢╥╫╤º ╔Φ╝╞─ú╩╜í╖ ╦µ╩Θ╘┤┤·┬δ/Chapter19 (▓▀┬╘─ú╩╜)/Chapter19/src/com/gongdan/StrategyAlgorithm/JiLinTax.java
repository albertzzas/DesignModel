package com.gongdan.StrategyAlgorithm;

public class JiLinTax implements Tax
{
    public void computeTax()
    {
        System.out.println("采用吉林算法计算所得税");
    }
}
