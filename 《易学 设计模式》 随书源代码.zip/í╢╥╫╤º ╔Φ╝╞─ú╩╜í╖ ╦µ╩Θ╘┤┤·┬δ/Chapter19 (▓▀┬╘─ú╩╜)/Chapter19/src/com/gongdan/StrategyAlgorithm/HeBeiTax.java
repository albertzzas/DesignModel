package com.gongdan.StrategyAlgorithm;

public class HeBeiTax implements Tax
{
    public void computeTax()
    {
        System.out.println("采用河北算法计算所得税");
    }
}
