package com.gongdan.Strategy;

public class Context
{
    private Strategy lnkStrategy;

    public void operation()
    {
        lnkStrategy.operation();
    }
}
