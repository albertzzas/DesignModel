package com.gongdan.Strategy;

public class HeBeiInsurance
{
    public void computeInsurance()
    {
        System.out.println("采用河北算法计算保险");
    }
}
