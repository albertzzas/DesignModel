package com.gongdan.Strategy;

public class HeBeiTax
{
    public void computeTax()
    {
        System.out.println("采用河北算法计算所得税");
    }
}
