package com.gongdan.Strategy;

public class Strategy1 implements Strategy
{
    public void operation()
    {

    }
}
