package com.gongdan.Strategy;

public class JiLinTax
{
    public void computeTax()
    {
        System.out.println("采用吉林算法计算所得税");
    }
}
