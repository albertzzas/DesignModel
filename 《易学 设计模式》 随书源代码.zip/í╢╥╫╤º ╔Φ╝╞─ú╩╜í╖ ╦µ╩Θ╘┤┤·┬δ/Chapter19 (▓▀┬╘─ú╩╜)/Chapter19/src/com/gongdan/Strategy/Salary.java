package com.gongdan.Strategy;

public class Salary
{
    public void computeHeBeiSalary()
    {
        System.out.println("采用河北算法计算基本工资");
    }

    public void computeJiLinSalary()
    {
        System.out.println("采用吉林算法计算基本工资");
    }
}
