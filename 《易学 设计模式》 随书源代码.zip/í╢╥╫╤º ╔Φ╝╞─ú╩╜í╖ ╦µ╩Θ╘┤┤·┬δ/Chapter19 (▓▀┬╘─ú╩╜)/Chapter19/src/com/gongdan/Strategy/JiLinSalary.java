package com.gongdan.Strategy;

public class JiLinSalary
{
    public void computeSalary()
    {
        System.out.println("采用吉林算法计算基本工资");
    }
}
