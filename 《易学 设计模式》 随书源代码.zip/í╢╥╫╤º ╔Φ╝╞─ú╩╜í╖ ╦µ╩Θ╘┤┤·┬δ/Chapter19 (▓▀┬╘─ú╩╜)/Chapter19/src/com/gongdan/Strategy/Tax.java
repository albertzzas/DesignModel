package com.gongdan.Strategy;

public class Tax
{
    public void computeHeBeiTax()
    {
        System.out.println("采用河北算法计算所得税");
    }

    public void computeJiLinTax()
    {
        System.out.println("采用吉林算法计算所得税");
    }
}
