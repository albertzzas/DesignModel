package com.gongdan.Strategy;

public class Insurance
{
    public void computeHeBeiInsurance()
    {
        System.out.println("采用河北算法计算保险");
    }

    public void computeJiLinInsurance()
    {
        System.out.println("采用吉林算法计算保险");
    }
}
