package com.gongdan.Strategy;

public class HeBeiSalary
{
    public void computeSalary()
    {
        System.out.println("采用河北算法计算基本工资");
    }
}
