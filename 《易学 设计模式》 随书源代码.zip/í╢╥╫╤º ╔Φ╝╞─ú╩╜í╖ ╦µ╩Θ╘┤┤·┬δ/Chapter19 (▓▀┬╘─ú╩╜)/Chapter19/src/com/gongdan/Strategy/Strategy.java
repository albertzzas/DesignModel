package com.gongdan.Strategy;

public interface Strategy
{
    public void operation();
}
