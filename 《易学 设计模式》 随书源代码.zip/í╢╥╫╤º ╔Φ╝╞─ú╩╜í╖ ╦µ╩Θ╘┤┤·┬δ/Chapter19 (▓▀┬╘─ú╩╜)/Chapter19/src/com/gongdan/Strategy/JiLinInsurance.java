package com.gongdan.Strategy;

public class JiLinInsurance
{
    public void computeInsurance()
    {
        System.out.println("采用吉林算法计算保险");
    }
}
