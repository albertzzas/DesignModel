package com.gongdan.Strategy;

public class Strategy2 implements Strategy
{
    public void operation()
    {

    }
}
