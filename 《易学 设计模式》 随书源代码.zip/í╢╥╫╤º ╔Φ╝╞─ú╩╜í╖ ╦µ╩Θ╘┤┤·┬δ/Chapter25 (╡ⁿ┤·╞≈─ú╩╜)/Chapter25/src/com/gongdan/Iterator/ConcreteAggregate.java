package com.gongdan.Iterator;

public class ConcreteAggregate implements Aggregate
{
    public Iterator CreateIterator()
    {
        return new ConcreteIterator();
    }
}
