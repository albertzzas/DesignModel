package com.gongdan.Iterator;

public interface Aggregate
{
    Iterator CreateIterator();
}
