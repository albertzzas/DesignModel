package com.gongdan.Iterator;

public interface Iterator
{
    void next();

    void first();
}
