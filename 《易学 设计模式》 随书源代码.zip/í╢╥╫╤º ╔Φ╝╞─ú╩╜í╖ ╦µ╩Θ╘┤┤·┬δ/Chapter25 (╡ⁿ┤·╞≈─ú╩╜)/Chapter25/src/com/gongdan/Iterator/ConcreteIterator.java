package com.gongdan.Iterator;

public class ConcreteIterator implements Iterator
{
    public void next()
    {

    }

    public void first()
    {

    }

    private ConcreteAggregate lnkConcreteAggregate;
}
