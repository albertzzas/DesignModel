package com.gongdan.Prototype;

public interface Prototype extends Cloneable
{
    public Object Clone();
}
