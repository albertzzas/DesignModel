package com.gongdan.Prototype;

public class NewDogClone implements Cloneable
{
    public int legCounts;

    public NewDog newDog = new NewDog(4);

    public Object Clone()
    {
        NewDogClone o = null;

        try
        {
            o = (NewDogClone)super.clone();
        }
        catch (CloneNotSupportedException ex)
        {
            ex.printStackTrace();
        }
        o.newDog = (NewDog)newDog.Clone();
        return o;
    }
}
