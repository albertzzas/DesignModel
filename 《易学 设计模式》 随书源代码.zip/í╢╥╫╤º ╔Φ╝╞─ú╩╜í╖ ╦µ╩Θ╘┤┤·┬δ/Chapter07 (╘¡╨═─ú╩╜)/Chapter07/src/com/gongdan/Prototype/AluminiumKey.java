package com.gongdan.Prototype;

public class AluminiumKey extends KeyPrototype
{
    public AluminiumKey()
    {
        setColor("银色");
    }
}
