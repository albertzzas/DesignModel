package com.gongdan.Prototype;

public class DogClone implements Cloneable
{
    public int legCounts;

    public Dog dog = new Dog(4);

    public Object Clone()
    {
        DogClone o = null;

        try
        {
            o = (DogClone)super.clone();
        }
        catch (CloneNotSupportedException ex)
        {
            ex.printStackTrace();
        }
        return o;
    }
}
