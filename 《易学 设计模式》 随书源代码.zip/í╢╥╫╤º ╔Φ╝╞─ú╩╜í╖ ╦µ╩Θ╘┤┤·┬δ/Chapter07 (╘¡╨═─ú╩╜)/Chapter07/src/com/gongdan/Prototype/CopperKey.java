package com.gongdan.Prototype;

public class CopperKey extends KeyPrototype
{
    public CopperKey()
    {
        setColor("黄色");
    }
}
