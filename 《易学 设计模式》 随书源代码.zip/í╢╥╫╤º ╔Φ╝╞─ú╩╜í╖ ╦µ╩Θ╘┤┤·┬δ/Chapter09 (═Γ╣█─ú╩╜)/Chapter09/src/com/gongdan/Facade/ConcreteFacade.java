package com.gongdan.Facade;

public class ConcreteFacade implements Facade
{
    public void operation1()
    {
        SubSystem subSystem = new SubSystem();
        subSystem.operaion1();
    }

    public void operation2()
    {
        SubSystem subSystem = new SubSystem();
        subSystem.operaion2();
    }
}
