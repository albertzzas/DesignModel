package com.gongdan.Facade;

public class SubSystem
{
    public SubSystem()
    {
    }

    public void operaion1()
    {
        System.out.println("子系统操作1");
    }

    public void operaion2()
    {
        System.out.println("子系统操作2");
    }
}
