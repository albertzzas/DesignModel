package com.gongdan.Facade;

public interface Facade
{
    void operation1();
    void operation2();
}
