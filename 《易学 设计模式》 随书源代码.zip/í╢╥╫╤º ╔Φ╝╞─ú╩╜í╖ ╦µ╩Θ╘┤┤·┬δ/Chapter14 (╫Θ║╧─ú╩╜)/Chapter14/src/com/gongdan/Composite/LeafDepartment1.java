package com.gongdan.Composite;

public class LeafDepartment1 implements Organ
{
    public int personCount()
    {
        return 100;
    }
}
