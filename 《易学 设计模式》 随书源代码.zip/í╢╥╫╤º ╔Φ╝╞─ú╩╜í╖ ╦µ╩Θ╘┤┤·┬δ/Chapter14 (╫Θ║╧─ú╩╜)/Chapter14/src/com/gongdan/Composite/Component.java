package com.gongdan.Composite;

public interface Component
{
    Composite getComposite();

    void sampleOperation();
}
