package com.gongdan.Composite;

public class LeafDepartment2 implements Organ
{
    public int personCount()
    {
        return 200;
    }
}
