package com.gongdan.Composite;

public class Leaf implements Component
{
    public Composite getComposite()
    {
        return null;
    }

    public void sampleOperation()
    {

    }
}
