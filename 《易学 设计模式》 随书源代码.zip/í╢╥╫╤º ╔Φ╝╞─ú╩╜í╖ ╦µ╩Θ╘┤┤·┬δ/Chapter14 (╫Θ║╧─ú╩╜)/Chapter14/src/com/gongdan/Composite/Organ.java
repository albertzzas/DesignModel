package com.gongdan.Composite;

public interface Organ
{
    public int personCount();
}
