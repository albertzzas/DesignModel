package com.gongdan;

public class Client
{
    public static void main(String[] args)
    {
        LogManager.log("设计模式从入门到精通");
    }
}