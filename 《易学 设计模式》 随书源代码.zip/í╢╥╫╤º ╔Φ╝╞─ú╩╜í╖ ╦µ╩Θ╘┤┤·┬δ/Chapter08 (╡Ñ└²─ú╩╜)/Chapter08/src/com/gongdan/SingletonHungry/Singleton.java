package com.gongdan.SingletonHungry;

public class Singleton
{
    private static Singleton instance = new Singleton();

    protected Singleton()
    {
    }

    public static Singleton getInstance()
    {
        return instance;
    }
}
