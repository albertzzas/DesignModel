package com.gongdan.SingletonLazy;

public class Singleton
{
    protected Singleton()
    {
    }

    private static Singleton instance = null;

    public static synchronized Singleton getInstance()
    {
        if (instance == null)
        {
            return new Singleton();
        }
        return instance;
    }
}