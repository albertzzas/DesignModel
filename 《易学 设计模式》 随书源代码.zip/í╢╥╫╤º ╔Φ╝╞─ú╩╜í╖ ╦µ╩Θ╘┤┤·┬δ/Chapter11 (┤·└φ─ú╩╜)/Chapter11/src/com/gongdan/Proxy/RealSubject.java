package com.gongdan.Proxy;

public class RealSubject implements Subject
{
    public void sampleOperation()
    {

    }
}
