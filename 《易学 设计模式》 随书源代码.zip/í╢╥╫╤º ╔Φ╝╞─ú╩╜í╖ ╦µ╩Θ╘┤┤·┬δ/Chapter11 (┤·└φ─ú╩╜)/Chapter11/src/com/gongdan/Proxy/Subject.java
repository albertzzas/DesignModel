package com.gongdan.Proxy;

public interface Subject
{
    public void sampleOperation();
}
