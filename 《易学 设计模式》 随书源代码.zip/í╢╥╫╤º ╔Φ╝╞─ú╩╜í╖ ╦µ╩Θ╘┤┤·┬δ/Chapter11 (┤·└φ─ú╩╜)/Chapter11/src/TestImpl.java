public class TestImpl implements Test
{
    public void doLogic(String name)
    {

    }
}
