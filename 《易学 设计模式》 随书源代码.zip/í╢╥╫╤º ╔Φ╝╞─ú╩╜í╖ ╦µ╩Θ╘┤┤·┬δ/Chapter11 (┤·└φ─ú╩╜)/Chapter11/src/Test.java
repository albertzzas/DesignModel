public interface Test
{
    public void doLogic(String name);
}
