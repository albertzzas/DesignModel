package com.gongdan.Adapter;

public interface Target
{
    void operation1();
    void operation2();
}
