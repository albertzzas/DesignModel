package com.gongdan.Adapter;

public class Adaptee
{
    public void operation1() {}
    public void operation2() {};
}
