package com.gongdan.Responsibility;

public class XiaoGongNew
{
    public boolean isSleep()
    {
        return sleep;
    }

    public void setSleep(boolean sleep)
    {
        this.sleep = sleep;
    }

    private boolean sleep;

    public boolean isHead()
    {
        return head;
    }

    public void setHead(boolean head)
    {
        this.head = head;
    }

    private boolean head;

    public boolean isStomach()
    {
        return stomach;
    }

    public void setStomach(boolean stomach)
    {
        this.stomach = stomach;
    }

    private boolean stomach;
}
