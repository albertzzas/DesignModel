package com.gongdan.AbstractFactory;

public class HeBeiFactory implements Factory1
{
    public Salary CreateSalary()
    {
        return new HeBeiSalary();
    }

    public Insurance CreateInsurance()
    {
        return new HeBeiInsurance();
    }

    public Tax CreateTax()
    {
        return new HeBeiTax();
    }
}
