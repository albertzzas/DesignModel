package com.gongdan.AbstractFactory;

import com.gongdan.Builder.Director1;

public class Client1
{
    public static void main(String args[])
    {
        Director1 director1 = new Director1(new HeBeiFactory());
        director1.Compute();
    }
}
