package com.gongdan.AbstractFactory;

import com.gongdan.Builder.*;

public class MotorcycleFactory implements Factory
{
    public Carcase CreateCarcase()
    {
        return new Carcase1();
    }

    public Wheel CreateWheel()
    {
        return new Wheel1();
    }

    public Tyre CreateTyre()
    {
        return new Tyre1();
    }

    public Engine CreateEngine()
    {
        return new Engine1();
    }
}
