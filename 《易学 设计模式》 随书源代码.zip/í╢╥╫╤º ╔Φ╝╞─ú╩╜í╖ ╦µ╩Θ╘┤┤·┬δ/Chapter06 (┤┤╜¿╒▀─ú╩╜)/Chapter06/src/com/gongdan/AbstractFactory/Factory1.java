package com.gongdan.AbstractFactory;

public interface Factory1
{
    public Salary CreateSalary();
    public Insurance CreateInsurance();
    public Tax CreateTax();
}
