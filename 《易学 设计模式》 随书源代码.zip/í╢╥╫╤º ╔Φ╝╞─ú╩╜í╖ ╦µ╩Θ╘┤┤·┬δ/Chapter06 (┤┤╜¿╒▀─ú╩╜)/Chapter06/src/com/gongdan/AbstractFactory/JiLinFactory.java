package com.gongdan.AbstractFactory;

public class JiLinFactory implements Factory1
{
    public Salary CreateSalary()
    {
        return new JiLinSalary();
    }

    public Insurance CreateInsurance()
    {
        return new JiLinInsurance();
    }

    public Tax CreateTax()
    {
        return new JiLinTax();
    }
}
