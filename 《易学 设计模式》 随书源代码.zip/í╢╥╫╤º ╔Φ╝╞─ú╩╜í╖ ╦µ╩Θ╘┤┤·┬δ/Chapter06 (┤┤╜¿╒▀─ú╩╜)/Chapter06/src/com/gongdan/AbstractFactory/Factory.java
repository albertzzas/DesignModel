package com.gongdan.AbstractFactory;

import com.gongdan.Builder.Carcase;
import com.gongdan.Builder.Engine;
import com.gongdan.Builder.Tyre;
import com.gongdan.Builder.Wheel;

public interface Factory
{
    Carcase CreateCarcase();
    Wheel CreateWheel();
    Tyre CreateTyre();
    Engine CreateEngine();
}