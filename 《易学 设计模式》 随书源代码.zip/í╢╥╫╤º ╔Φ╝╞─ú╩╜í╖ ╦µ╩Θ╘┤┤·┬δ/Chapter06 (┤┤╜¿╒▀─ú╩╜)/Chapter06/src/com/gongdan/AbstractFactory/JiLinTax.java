package com.gongdan.AbstractFactory;

public class JiLinTax implements Tax
{
    public void ComputeTax()
    {
        System.out.println("开始计算吉林子公司的所得税");
    }
}
