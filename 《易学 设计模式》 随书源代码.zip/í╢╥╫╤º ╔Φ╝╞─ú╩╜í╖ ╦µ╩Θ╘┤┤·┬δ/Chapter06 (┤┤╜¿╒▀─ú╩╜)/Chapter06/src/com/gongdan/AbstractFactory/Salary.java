package com.gongdan.AbstractFactory;

public interface Salary
{
    public void ComputeSalary();
}
