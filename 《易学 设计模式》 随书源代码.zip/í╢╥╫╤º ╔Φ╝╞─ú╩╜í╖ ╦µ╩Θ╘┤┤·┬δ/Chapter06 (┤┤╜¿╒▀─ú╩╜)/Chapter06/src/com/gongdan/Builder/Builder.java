package com.gongdan.Builder;

public interface Builder
{
    public void Operation();
}
