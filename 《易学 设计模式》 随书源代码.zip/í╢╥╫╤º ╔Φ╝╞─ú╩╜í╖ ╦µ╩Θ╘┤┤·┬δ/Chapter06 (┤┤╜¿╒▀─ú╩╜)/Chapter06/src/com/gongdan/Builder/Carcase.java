package com.gongdan.Builder;

public interface Carcase
{
    public void Build();
}
