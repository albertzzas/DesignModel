package com.gongdan.Builder;

public interface Tyre
{
    public void Build();
}
