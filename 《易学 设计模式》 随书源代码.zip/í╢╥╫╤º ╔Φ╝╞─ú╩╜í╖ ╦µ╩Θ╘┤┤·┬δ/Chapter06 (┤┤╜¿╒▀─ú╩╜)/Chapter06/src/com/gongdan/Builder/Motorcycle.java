package com.gongdan.Builder;

public interface Motorcycle
{
    public void Build();
}
