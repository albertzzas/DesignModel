package com.gongdan.Builder;

public interface Engine
{
    public void Build();
}
