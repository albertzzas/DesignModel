package com.gongdan.Builder;

import com.gongdan.Builder.Motorcycle;

public class Motorcycle1 implements Motorcycle
{
    public void Build()
    {
        System.out.println("组装摩托车开始");
    }
}
