package com.gongdan.Builder;

public class Engine1 implements Engine
{
    public void Build()
    {
        System.out.println("组装摩托车发动机开始");
    }
}
