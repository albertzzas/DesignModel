package com.gongdan.Builder;

public class Tyre1 implements Tyre
{
    public void Build()
    {
        System.out.println("组装摩托车轮胎开始");
    }
}
