package com.gongdan.Builder;

public interface Wheel
{
    public void Build();
}
