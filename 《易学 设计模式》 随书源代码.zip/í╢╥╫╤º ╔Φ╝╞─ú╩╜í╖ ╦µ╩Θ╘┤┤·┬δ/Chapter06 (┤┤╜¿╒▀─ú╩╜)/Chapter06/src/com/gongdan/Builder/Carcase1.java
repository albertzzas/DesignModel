package com.gongdan.Builder;

public class Carcase1 implements  Carcase
{
    public void Build()
    {
        System.out.println("组装摩托车架开始");
    }
}
