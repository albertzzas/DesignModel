package com.gongdan.Builder;

public interface Product
{
    public void Operation();
}
