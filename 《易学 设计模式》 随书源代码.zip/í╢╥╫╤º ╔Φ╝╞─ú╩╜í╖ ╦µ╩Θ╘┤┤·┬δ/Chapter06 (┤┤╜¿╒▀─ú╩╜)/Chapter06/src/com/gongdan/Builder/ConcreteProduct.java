package com.gongdan.Builder;

public class ConcreteProduct implements Product
{
    public void Operation()
    {

    }
}
