package com.gongdan.Builder;

public class DirectorProduct
{
    private Builder builder;

    public DirectorProduct(Builder builder)
    {
        this.builder = builder;
    }

    public Product AssembleProduct()
    {
        return new ConcreteProduct();
    }
}
