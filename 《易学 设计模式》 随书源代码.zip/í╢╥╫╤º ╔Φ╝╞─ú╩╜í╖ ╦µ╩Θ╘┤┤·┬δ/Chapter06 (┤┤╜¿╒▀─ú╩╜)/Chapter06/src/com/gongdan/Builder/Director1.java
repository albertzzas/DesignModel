package com.gongdan.Builder;

import com.gongdan.AbstractFactory.Factory1;
import com.gongdan.AbstractFactory.Insurance;
import com.gongdan.AbstractFactory.Salary;
import com.gongdan.AbstractFactory.Tax;

public class Director1
{
    private Factory1 factory1;

    public Director1(Factory1 factory1)
    {
        this.factory1 = factory1;
    }

    public void Compute()
    {
        Salary salary = factory1.CreateSalary();
        salary.ComputeSalary();
        Insurance insurance = factory1.CreateInsurance();
        insurance.ComputeInsurance();
        Tax tax = factory1.CreateTax();
        tax.ComputeTax();
    }
}
