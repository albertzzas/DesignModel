package com.gongdan.Builder;

public class ConcreteBuilder implements Builder
{
    public void Operation()
    {

    }
}
