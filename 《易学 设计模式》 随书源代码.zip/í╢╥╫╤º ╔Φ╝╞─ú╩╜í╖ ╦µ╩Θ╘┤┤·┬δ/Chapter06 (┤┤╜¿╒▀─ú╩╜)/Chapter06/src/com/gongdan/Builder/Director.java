package com.gongdan.Builder;

import com.gongdan.AbstractFactory.Factory;

public class Director
{
    private Factory factory;

    public Director(Factory factory)
    {
        this.factory = factory;
    }

    public Motorcycle AssembleMotorcycle()
    {
        Carcase carcase = factory.CreateCarcase();
        carcase.Build();
        Wheel wheel = factory.CreateWheel();
        wheel.Build();
        Tyre tyre = factory.CreateTyre();
        tyre.Build();
        Engine engine = factory.CreateEngine();
        engine.Build();

        return new Motorcycle1();
    }
}
