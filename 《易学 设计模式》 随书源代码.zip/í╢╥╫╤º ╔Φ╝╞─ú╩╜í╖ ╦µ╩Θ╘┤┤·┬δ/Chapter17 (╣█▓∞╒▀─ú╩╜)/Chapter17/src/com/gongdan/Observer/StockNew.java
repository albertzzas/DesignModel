package com.gongdan.Observer;

public class StockNew extends StockSubject
{
    public void changeCount()
    {
        setName("中信证券");
        super.changeCount();
    }

    public void changePrice()
    {
        setName("中信证券");
        super.changePrice();
    }
}
