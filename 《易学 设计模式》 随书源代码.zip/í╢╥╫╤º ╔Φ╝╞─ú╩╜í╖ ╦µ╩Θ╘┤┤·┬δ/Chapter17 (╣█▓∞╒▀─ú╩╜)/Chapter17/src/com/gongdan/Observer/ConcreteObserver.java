package com.gongdan.Observer;

public class ConcreteObserver implements Observer
{
    public void update()
    {

    }
}
