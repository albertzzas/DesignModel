package com.gongdan.Observer;

public interface StockObserver
{
    public void updatePrice(String name);

    public void updateCount(String name);
}
