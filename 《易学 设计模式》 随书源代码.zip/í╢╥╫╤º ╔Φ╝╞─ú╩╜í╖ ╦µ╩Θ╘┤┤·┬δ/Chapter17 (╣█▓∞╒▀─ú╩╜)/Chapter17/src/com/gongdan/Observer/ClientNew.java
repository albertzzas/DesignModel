package com.gongdan.Observer;

public class ClientNew
{
    public static void main(String[] args)
    {
        StockNew stockNew = new StockNew();
        stockNew.add(new PhoneClientObserver());
        stockNew.add(new ComputerClientObserver());
        stockNew.changePrice();
        stockNew.changeCount();
    }
}
