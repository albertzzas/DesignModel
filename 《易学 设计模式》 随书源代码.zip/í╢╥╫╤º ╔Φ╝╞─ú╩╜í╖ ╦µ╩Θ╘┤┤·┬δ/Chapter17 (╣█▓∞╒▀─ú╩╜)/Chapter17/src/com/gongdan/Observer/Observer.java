package com.gongdan.Observer;

public interface Observer
{
    public void update();
}
