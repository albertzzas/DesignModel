package com.gongdan.State;

public interface State
{
    public void handle(DocumentState documentState);
}
