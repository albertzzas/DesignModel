package com.gongdan.State;

public class CreatedState implements State
{
    public void handle(DocumentState documentState)
    {
        documentState.setState(new SendOneChargeState());
        System.out.println("公文已 发送二级主管");
    }
}
