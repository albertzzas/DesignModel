package com.gongdan.State;

public class CreatingState implements State
{
    public void handle(DocumentState documentState)
    {
        documentState.setState(new CreatedState());
        System.out.println("公文已 创建完成");
    }
}
