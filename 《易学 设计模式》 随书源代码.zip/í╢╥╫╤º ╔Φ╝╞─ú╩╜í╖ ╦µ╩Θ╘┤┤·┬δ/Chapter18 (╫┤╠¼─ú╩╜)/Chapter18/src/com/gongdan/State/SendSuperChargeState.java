package com.gongdan.State;

public class SendSuperChargeState implements State
{
    public void handle(DocumentState documentState)
    {
        documentState.setState(new ApprovedState());
        System.out.println("公文已 审批完成");
    }
}
