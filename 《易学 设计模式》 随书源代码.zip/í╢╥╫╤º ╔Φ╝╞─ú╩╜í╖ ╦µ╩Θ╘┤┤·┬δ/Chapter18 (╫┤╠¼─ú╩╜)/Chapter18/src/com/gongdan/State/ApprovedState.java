package com.gongdan.State;

public class ApprovedState implements State
{
    public void handle(DocumentState documentState)
    {
        System.out.println("公文已 结束");
    }
}
