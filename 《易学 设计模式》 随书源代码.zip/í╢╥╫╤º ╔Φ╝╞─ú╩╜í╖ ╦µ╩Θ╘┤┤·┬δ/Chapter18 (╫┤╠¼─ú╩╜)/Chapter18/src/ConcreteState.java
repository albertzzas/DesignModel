public class ConcreteState implements State
{
    public void sampleOperation()
    {

    }
}
