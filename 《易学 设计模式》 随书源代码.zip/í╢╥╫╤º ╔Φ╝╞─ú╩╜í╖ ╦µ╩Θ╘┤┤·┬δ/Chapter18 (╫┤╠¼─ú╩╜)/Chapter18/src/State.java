public interface State
{
    public void sampleOperation();
}
