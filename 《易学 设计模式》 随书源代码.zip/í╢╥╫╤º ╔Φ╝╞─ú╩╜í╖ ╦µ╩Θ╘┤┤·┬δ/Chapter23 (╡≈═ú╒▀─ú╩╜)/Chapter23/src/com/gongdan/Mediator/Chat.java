package com.gongdan.Mediator;

public interface Chat
{
    void send(String personFrom, String personTo, String message);

    void add(Person person);
}
