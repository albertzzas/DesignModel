package com.gongdan.Mediator;

public class Colleague2 implements Colleague
{

}
