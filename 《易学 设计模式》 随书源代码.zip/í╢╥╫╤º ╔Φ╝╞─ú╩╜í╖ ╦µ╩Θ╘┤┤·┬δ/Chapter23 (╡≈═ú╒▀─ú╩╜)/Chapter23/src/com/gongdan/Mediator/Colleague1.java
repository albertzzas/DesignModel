package com.gongdan.Mediator;

public class Colleague1 implements Colleague
{

}
