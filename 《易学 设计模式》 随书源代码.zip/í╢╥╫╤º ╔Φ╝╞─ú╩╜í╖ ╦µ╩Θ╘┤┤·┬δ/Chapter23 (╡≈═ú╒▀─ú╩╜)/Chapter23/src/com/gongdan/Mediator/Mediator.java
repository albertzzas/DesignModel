package com.gongdan.Mediator;

public interface Mediator
{

}
