package com.gongdan.Mediator;

public class PersonB
{
    public void sendMessage()
    {

    }

    public void receiveMessge()
    {

    }
}
