package com.gongdan.Mediator;

public class PersonC
{
    public void sendMessage()
    {

    }

    public void receiveMessge()
    {

    }
}
