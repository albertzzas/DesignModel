package com.gongdan.Mediator;

public class ConcreteMediator implements Mediator
{
    private Colleague1 lnkColleague1;
    private Colleague1 lnkColleague2;
}
