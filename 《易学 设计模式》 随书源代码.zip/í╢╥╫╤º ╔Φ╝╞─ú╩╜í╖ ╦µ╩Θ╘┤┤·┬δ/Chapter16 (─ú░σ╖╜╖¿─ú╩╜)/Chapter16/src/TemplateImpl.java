public class TemplateImpl extends Template
{
    public void Operation1()
    {

    }

    public void Operation2()
    {

    }

    public void Operation3()
    {

    }
}
