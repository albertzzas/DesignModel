package com.gongdan.Template;

public class Client
{
    public static void main(String[] args)
    {
        Report report = new ReportImpl();
        report.print();

        System.out.println("**********");

        report = new ReportImpl1();
        report.print();

        System.out.println("**********");

        SalaryTemplate salaryTemplate = new JiLinSalaryTemplate();
        salaryTemplate.compute();

        System.out.println("**********");

        salaryTemplate = new HeBeiSalaryTemplate();
        salaryTemplate.compute();
    }
}