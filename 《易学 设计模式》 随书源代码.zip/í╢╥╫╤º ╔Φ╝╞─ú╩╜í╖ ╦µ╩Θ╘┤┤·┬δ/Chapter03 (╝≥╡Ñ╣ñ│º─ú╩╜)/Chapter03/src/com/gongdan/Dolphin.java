package com.gongdan;

public class Dolphin implements Animal
{
    public void Swim()
    {
        System.out.println("海豚会游泳");
    }

    public void Eat()
    {
        System.out.println("海豚会吃");
    }
}
