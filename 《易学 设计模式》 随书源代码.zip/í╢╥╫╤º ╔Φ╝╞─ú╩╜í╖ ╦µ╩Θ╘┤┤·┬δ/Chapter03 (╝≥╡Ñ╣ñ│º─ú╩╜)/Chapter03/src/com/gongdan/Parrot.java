package com.gongdan;

public class Parrot implements Animal
{
    public void Fly()
    {
        System.out.println("鹦鹉会飞");
    }

    public void Eat()
    {
        System.out.println("鹦鹉会吃");
    }
}
