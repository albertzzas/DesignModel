package com.gongdan;

import com.gongdan.sampleFactory.Salary;

public class Client
{
    public static void main(String args[])
    {
        Animal animal = SampleFactory.CreateAnimal("Tiger");
        animal.Eat();
        animal = SampleFactory.CreateAnimal("Dolphin");
        animal.Eat();
        animal = SampleFactory.CreateAnimal("Parrot");
        animal.Eat();

        Salary salary = com.gongdan.sampleFactory.SampleFactory.CreateSalary("HeBei");
        salary.ComputeSalary();
        salary = com.gongdan.sampleFactory.SampleFactory.CreateSalary("JiLin");
        salary.ComputeSalary();
    }
}
