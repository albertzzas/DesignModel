package com.gongdan;

public class Tiger implements Animal
{
    public void Eat()
    {
        System.out.println("老虎会吃");
    }

    public void Run()
    {
        System.out.println("老虎会跑");
    }
}
