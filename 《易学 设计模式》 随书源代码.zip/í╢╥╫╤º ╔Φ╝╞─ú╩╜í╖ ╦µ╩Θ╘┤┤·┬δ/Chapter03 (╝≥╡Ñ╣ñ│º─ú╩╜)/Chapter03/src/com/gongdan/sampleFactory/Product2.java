package com.gongdan.sampleFactory;

public class Product2 implements Product
{
    public void Operation1()
    {

    }
}
