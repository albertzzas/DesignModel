package com.gongdan.sampleFactory;

public class SampleFactory
{
    public static Product CreateProduct(String productName)
    {
        if ("1".equals(productName))
        {
            return new Product1();
        }
        else if ("2".equals(productName))
        {
            return new Product2();
        }
        return null;
    }

    public static Salary CreateSalary(String name)
    {
        if ("HeBei".equals(name))
        {
            return new HeBeiSalary();
        }
        else if ("JiLin".equals(name))
        {
            return new JiLinSalary();
        }
        return null;
    }
}
