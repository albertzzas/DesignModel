package com.gongdan.sampleFactory;

public interface Salary
{
    void ComputeSalary();
}
