package com.gongdan.sampleFactory;

public interface Product
{
    void Operation1();
}
