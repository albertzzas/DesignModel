package com.gongdan.Interpreter;

public interface Interpreter
{
    void parse(Context context);
}
