package com.gongdan.Interpreter;

public class AbstractExpression
{
    public void interpreter()
    {

    }
}
