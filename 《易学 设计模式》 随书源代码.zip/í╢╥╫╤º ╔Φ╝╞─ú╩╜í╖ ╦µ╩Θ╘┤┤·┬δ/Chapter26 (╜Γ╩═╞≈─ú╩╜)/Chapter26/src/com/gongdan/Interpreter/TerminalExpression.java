package com.gongdan.Interpreter;

public class TerminalExpression extends AbstractExpression
{
    public void interpreter()
    {

    }
}
