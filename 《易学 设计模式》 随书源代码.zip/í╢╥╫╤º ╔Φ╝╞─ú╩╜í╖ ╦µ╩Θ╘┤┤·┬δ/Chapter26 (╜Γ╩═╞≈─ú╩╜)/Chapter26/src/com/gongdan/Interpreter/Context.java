package com.gongdan.Interpreter;

public class Context
{
    public Context(String str)
    {
        this.str = str;
    }

    public String getStr()
    {
        return str;
    }

    private String str;
}
