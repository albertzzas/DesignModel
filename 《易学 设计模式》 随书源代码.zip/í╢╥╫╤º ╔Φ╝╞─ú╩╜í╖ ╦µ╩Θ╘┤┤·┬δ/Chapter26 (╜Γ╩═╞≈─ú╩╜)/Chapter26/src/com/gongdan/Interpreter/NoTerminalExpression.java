package com.gongdan.Interpreter;

public class NoTerminalExpression extends AbstractExpression
{
    public void interpreter()
    {

    }
}
