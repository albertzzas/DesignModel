package com.gongdan;

public interface Salary
{
    public void ComputeSalary();
}
