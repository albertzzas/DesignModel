package com.gongdan;

public interface Animal
{
    public void Eat();
}
