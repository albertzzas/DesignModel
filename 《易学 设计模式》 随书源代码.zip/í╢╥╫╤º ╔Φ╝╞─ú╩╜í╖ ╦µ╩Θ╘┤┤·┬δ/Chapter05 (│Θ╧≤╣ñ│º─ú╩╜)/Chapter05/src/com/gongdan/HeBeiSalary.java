package com.gongdan;

public class HeBeiSalary implements Salary
{
    public void ComputeSalary()
    {
        System.out.println("正在计算河北子公司的薪资");
    }
}
