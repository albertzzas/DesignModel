package com.gongdan.FactoryMethod;

import com.gongdan.Salary;

public interface Factory
{
    public Salary CreateSalary();
}
