package com.gongdan.FactoryMethod;

import com.gongdan.JiLinSalary;
import com.gongdan.Salary;

public class JiLinSalaryFactory implements Factory
{
    public Salary CreateSalary()
    {
        return new JiLinSalary();
    }
}
