package com.gongdan.FactoryMethod;

import com.gongdan.Salary;

public class Client
{
    public static void main(String args[])
    {
        Factory factory = new HeBeiSalaryFactory();
        Salary salary = factory.CreateSalary();
        salary.ComputeSalary();
        factory = new JiLinSalaryFactory();
        salary = factory.CreateSalary();
        salary.ComputeSalary();
    }
}
