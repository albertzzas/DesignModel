package com.gongdan.FactoryMethod;

import com.gongdan.HeBeiSalary;
import com.gongdan.Salary;

public class HeBeiSalaryFactory implements Factory
{
    public Salary CreateSalary()
    {
        return new HeBeiSalary();
    }
}
