package com.gongdan.AbstractFactory;

public class HeBeiTax implements Tax
{
    public void ComputeTax()
    {
        System.out.println("正在计算河北子公司的所得税");
    }
}
