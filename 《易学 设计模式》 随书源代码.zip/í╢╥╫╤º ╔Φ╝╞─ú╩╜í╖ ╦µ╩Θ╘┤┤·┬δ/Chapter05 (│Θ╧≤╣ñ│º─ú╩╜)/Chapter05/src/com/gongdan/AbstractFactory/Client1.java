package com.gongdan.AbstractFactory;

import com.gongdan.Salary;

public class Client1
{
    public static void main(String args[])
    {
        Factory1 factory1 = new HeBeiFactory();
        Salary salary = factory1.CreateSalary();
        salary.ComputeSalary();
        Insurance insurance = factory1.CreateInsurance();
        insurance.ComputeInsurance();
        Tax tax = factory1.createTax();
        tax.ComputeTax();

        factory1 = new JiLinFactory();
        salary = factory1.CreateSalary();
        salary.ComputeSalary();
        insurance = factory1.CreateInsurance();
        insurance.ComputeInsurance();
        tax = factory1.createTax();
        tax.ComputeTax();
    }
}
