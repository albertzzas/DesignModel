package com.gongdan.AbstractFactory;

public class ConcreteProduct implements AbstractProduct
{
    
}
