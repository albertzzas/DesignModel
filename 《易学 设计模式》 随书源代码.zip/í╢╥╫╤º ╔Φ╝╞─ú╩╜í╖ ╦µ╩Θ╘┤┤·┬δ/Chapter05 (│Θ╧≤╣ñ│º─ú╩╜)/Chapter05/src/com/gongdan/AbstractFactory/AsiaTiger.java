package com.gongdan.AbstractFactory;

import com.gongdan.Tiger;

public class AsiaTiger extends Tiger
{
    public void Run()
    {
        System.out.println("亚洲虎会跑");
    }

    public void Eat()
    {
        System.out.println("亚洲虎会吃");
    }
}
