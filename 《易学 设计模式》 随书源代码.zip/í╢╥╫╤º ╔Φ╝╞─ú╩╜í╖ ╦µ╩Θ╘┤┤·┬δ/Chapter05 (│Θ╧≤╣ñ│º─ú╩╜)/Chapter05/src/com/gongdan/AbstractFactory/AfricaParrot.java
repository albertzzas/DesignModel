package com.gongdan.AbstractFactory;

import com.gongdan.Parrot;

public class AfricaParrot extends Parrot
{
    public void Fly()
    {
        System.out.println("非洲鹦鹉会飞");
    }

    public void Eat()
    {
        System.out.println("非洲鹦鹉会吃");
    }
}
