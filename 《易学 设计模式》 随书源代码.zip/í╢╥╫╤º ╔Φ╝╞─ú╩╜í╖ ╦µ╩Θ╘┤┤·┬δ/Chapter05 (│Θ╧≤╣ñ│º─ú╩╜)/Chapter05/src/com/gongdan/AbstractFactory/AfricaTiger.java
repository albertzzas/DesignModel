package com.gongdan.AbstractFactory;

import com.gongdan.Tiger;

public class AfricaTiger extends Tiger
{
    public void Run()
    {
        System.out.println("非洲虎会跑");
    }

    public void Eat()
    {
        System.out.println("非洲虎会吃");
    }
}
