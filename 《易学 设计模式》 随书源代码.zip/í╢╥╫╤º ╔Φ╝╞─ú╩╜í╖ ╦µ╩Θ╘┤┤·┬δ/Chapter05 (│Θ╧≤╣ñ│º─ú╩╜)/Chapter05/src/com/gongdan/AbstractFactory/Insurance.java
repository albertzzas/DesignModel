package com.gongdan.AbstractFactory;

public interface Insurance
{
    public void ComputeInsurance();
}
