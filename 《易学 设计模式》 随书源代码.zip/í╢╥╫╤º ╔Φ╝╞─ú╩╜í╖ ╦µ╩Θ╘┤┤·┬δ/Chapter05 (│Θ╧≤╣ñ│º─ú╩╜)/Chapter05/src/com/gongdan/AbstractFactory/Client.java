package com.gongdan.AbstractFactory;

import com.gongdan.Animal;

public class Client
{
    public static void main(String args[])
    {
        Factory factory = new AsiaFactory();
        Animal animal = factory.CreateTiger();
        animal.Eat();
        animal = factory.CreateDolphin();
        animal.Eat();
        animal = factory.CreateParrot();
        animal.Eat();

        factory = new AfricaFactory();
        animal = factory.CreateTiger();
        animal.Eat();
        animal = factory.CreateDolphin();
        animal.Eat();
        animal = factory.CreateParrot();
        animal.Eat();
    }
}
