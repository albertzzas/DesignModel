package com.gongdan.AbstractFactory;

public class JiLinInsurance implements Insurance
{
    public void ComputeInsurance()
    {
        System.out.println("开始计算吉林子公司的社会保险");
    }
}
