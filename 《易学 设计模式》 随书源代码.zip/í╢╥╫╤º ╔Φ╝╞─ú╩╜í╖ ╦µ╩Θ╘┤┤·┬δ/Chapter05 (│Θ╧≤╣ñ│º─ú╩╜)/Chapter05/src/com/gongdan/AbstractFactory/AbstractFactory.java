package com.gongdan.AbstractFactory;

public interface AbstractFactory
{
    AbstractProduct CreateAbstractProduct();
}
