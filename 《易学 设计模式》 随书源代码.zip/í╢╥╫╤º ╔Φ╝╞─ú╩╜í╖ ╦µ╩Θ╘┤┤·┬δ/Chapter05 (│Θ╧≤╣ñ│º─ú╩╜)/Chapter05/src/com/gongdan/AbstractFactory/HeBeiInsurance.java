package com.gongdan.AbstractFactory;

public class HeBeiInsurance implements Insurance
{
    public void ComputeInsurance()
    {
        System.out.println("开始计算河北子公司的社会保险");
    }
}
