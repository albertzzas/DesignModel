package com.gongdan.AbstractFactory;

public class ConcreteFactory implements AbstractFactory
{
    public AbstractProduct CreateAbstractProduct()
    {
        return new ConcreteProduct();
    }
}
