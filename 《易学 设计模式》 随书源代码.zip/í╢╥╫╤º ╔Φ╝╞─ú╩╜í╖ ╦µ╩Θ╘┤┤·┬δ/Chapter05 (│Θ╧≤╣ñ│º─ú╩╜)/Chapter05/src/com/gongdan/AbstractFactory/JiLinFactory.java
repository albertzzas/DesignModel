package com.gongdan.AbstractFactory;

import com.gongdan.JiLinSalary;
import com.gongdan.Salary;

public class JiLinFactory implements Factory1
{

    public Salary CreateSalary()
    {
        return new JiLinSalary();
    }

    public Insurance CreateInsurance()
    {
        return new JiLinInsurance();
    }

    public Tax createTax()
    {
        return new JiLinTax();
    }
}
