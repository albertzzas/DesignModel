package com.gongdan.AbstractFactory;

import com.gongdan.Dolphin;

public class AsiaDophin extends Dolphin
{
    public void Swim()
    {
        System.out.println("亚洲海豚会游泳");
    }

    public void Eat()
    {
        System.out.println("亚洲海豚会吃");
    }
}
