package com.gongdan.AbstractFactory;

import com.gongdan.Salary;

public interface Factory1
{
    Salary CreateSalary();
    Insurance CreateInsurance();
    Tax createTax();
}
