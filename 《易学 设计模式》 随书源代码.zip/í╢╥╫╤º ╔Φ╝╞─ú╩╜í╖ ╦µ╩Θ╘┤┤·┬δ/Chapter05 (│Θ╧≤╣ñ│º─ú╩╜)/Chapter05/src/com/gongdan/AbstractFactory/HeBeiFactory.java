package com.gongdan.AbstractFactory;

import com.gongdan.HeBeiSalary;
import com.gongdan.Salary;

public class HeBeiFactory implements Factory1
{

    public Salary CreateSalary()
    {
        return new HeBeiSalary();
    }

    public Insurance CreateInsurance()
    {
        return new HeBeiInsurance();
    }

    public Tax createTax()
    {
        return new HeBeiTax();
    }
}
