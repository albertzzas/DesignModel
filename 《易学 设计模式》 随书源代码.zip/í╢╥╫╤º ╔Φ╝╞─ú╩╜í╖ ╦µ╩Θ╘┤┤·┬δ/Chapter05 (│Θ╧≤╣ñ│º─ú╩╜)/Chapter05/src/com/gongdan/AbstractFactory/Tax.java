package com.gongdan.AbstractFactory;

public interface Tax
{
    public void ComputeTax();
}
