package com.gongdan.AbstractFactory;

import com.gongdan.Dolphin;
import com.gongdan.Parrot;
import com.gongdan.Tiger;

public class AsiaFactory implements Factory
{
    public Tiger CreateTiger()
    {
        return new AsiaTiger();
    }

    public Dolphin CreateDolphin()
    {
        return new AsiaDophin();
    }

    public Parrot CreateParrot()
    {
        return new AsiaParrot();
    }
}
