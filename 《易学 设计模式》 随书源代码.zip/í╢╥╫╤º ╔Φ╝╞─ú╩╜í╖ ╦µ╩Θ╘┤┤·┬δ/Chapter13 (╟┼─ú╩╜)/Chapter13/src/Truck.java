public class Truck implements Car
{
    public void produce()
    {

    }
}
