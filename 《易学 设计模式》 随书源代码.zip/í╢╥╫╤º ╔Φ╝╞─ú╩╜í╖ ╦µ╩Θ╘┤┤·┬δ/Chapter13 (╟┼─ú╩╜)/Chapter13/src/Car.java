public interface Car
{
    public void produce();
}
