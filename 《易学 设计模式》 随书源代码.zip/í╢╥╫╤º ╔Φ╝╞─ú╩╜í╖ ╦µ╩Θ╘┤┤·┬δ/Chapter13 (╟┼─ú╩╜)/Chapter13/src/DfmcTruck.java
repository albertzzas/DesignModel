public class DfmcTruck extends Truck
{
    public void produce()
    {
    }
}
