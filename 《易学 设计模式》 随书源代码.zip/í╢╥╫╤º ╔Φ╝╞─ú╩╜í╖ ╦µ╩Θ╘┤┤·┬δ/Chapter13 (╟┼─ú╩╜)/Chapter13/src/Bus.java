public class Bus implements Car
{
    public void produce()
    {

    }
}
