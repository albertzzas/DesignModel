public class FawBus extends Bus
{
    public void produce()
    {
    }
}
