package com.gongdan.Bridge;

public interface Implement
{
    public void Operation();
}
