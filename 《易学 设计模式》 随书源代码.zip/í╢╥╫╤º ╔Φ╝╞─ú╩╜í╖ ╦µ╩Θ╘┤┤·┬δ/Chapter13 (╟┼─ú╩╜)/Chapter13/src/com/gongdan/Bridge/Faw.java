package com.gongdan.Bridge;

public class Faw implements Manufacturer
{
    public void produce()
    {
        System.out.print("一汽制造");
    }
}
