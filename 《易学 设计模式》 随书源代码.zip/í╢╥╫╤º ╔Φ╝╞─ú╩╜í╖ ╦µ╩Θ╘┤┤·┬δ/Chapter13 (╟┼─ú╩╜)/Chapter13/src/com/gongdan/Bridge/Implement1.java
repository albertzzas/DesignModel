package com.gongdan.Bridge;

public class Implement1 implements Implement
{
    public void Operation()
    {

    }
}
