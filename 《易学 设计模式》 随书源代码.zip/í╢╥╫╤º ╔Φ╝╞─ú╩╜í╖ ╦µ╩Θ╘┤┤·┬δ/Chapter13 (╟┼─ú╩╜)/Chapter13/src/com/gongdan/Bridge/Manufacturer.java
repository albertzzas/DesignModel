package com.gongdan.Bridge;

public interface Manufacturer
{
    public void produce();
}
