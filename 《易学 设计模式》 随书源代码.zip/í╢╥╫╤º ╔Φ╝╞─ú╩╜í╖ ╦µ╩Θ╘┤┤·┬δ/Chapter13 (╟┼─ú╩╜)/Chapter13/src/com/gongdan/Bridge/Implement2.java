package com.gongdan.Bridge;

public class Implement2 implements Implement
{
    public void Operation()
    {

    }
}
