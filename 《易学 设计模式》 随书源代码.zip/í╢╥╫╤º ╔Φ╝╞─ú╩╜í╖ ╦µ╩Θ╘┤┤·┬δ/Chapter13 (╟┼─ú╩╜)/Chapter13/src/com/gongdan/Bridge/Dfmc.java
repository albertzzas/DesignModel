package com.gongdan.Bridge;

public class Dfmc implements Manufacturer
{
    public void produce()
    {
        System.out.print("二汽制造");
    }
}
