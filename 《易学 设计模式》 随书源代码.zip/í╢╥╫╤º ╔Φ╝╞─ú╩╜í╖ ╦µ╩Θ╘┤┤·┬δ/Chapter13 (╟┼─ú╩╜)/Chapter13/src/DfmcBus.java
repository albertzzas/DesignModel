public class DfmcBus extends Bus
{
    public void produce()
    {
    }
}
