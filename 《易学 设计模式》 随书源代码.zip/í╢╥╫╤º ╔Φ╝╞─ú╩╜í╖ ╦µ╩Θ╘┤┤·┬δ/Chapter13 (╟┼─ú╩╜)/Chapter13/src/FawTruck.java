public class FawTruck extends Truck
{
    public void produce()
    {
    }
}
