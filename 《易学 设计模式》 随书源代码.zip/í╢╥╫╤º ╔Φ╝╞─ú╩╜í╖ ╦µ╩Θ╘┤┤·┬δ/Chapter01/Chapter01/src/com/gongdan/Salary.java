package com.gongdan;

public interface Salary
{
    void ComputeSalary();
}
