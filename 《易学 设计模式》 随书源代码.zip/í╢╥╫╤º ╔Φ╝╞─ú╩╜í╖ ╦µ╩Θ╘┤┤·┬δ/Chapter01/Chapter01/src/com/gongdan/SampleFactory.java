package com.gongdan;

public class SampleFactory
{
    public static Salary CreateSalary(String name)
    {
        Class c = Class.forName(name);
        Salary salary = (Salary)c.newInstance();
        return salary;
    }
}
