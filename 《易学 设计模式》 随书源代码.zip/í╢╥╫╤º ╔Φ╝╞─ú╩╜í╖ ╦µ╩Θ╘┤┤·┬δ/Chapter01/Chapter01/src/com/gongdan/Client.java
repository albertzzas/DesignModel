package com.gongdan;

public class Client
{
    public Salary CreateSalary(String name)
    {
        Salary salary = null;
        if ("HeBei".equals(name))
        {
            salary = new HeBeiSalary();
        }
        else if ("JiLin".equals(name))
        {
            salary = new JiLinSalary();
        }
        return salary;
    }

    /*public void ComputeSalary(String name)
    {
        Salary salary = CreateSalary(name);
        salary.ComputeSalary();
    }*/

    public void ComputeSalary(String name)
    {
        Salary salary = SampleFactory.CreateSalary(name);
        salary.ComputeSalary();
    }
}
