public class ColorPhone extends Phone
{
    public void call(String name)
    {
        super.call(name);
    }
}
