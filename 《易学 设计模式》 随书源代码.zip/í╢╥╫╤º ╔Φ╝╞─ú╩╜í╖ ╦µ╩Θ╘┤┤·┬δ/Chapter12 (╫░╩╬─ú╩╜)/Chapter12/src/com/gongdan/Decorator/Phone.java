package com.gongdan.Decorator;

public interface Phone
{
    public void call(String name);
}
