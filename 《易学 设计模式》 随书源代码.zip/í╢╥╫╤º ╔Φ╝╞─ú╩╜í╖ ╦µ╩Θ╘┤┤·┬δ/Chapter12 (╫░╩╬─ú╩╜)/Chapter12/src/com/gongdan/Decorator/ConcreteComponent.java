package com.gongdan.Decorator;

public class ConcreteComponent implements Component
{
    public void sampleOperation()
    {

    }
}
