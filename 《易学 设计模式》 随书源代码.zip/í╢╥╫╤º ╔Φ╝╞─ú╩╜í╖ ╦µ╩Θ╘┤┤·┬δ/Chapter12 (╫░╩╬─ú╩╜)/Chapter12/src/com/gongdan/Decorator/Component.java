package com.gongdan.Decorator;

public interface Component
{
    public void sampleOperation();
}
