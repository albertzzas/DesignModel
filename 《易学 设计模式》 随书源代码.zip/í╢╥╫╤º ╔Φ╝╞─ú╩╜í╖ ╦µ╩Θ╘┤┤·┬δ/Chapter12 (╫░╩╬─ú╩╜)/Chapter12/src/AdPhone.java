public class AdPhone extends Phone
{
    public void call(String name)
    {
        super.call(name);
    }
}
