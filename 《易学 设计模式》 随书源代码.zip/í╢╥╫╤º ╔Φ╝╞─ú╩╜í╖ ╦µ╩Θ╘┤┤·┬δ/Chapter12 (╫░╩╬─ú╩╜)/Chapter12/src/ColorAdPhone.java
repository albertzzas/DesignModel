public class ColorAdPhone extends Phone
{
    public void call(String name)
    {
        super.call(name);
    }
}
