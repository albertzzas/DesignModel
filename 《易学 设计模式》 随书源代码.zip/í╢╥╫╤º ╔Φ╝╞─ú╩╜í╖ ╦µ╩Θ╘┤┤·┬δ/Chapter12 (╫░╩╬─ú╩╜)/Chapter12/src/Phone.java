public class Phone
{
    public void call(String name)
    {
    }
}
